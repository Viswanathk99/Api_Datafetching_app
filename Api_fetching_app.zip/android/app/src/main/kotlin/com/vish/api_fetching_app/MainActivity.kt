package com.vish.api_fetching_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
